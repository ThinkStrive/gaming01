import React from 'react'

const PayPal = () => {
  return (
    <div>PayPal</div>
  )
}

export default PayPal