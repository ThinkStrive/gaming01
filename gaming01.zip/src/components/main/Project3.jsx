import React from "react";

const Project3 = () => {
  return <div>Project3</div>;
};

export default Project3;
