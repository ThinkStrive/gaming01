import { backendUrl } from "../../../config";

export const USER_LOGIN = `${backendUrl}/authentication/login`
export const USER_REGISTER = `${backendUrl}/authentication/register`







export const USER_DETAILS = `${backendUrl}/users`