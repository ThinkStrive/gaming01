import React from 'react'

const Project2 = () => {
  return (
    <div>Project2</div>
  )
}

export default Project2