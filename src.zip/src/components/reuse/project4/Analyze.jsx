import React from "react";
import "../../../Style/Model.css";

const Analyze = () => {
  return (
    <div className="info-con">
      <div className="modal-container h-[80vh]">

      </div>
    </div>
  );
};

export default Analyze;
