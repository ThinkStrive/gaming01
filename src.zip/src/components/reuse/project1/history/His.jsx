import React from 'react'

const His = () => {
  return (
    <div>His</div>
  )
}

export default His